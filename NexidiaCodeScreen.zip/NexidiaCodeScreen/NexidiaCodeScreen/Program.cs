﻿using System;
using System.IO;
using System.Linq;

namespace NexidiaCodeScreen
{
   public class Program
    {
        public static void Main(string[] args)
        {
            string path = string.Empty;

            if (args.Any())
                    path = args[0];
            else
            {
                Console.WriteLine("Please enter the path to your Prime Factors Path :");
                path = Console.ReadLine();
            }

           ReadFileContents(path);

        }

    internal protected static void ReadFileContents(string _path)
    {

            if (File.Exists(_path))
            {
                PathReader pathReader = new PathReader();

                foreach (var line in pathReader.CreateReader(_path).ShowPrimeFactors())
                {
                    Console.WriteLine(line.ToString());
                }
            }
            else
            {
                Console.WriteLine($"File{_path} does not exist");
            }

        }
    }

    public interface IPathReader
    {
        TextReader CreateReader(string path);
    }

    public class PathReader : IPathReader
    {
        public TextReader CreateReader(string filePath)
        {
            return new StreamReader(filePath);
        }
    }
}

