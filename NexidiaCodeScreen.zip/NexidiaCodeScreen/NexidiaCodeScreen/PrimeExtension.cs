﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NexidiaCodeScreen
{
        public static class PrimeFactorExtension
        {
            public static IEnumerable<string> ShowPrimeFactors(this TextReader reader)
            {
                string line;

                while ((line = reader.ReadLine()) != null)

                if (line.IsInteger())
                {
                    yield return GeneratePrimes(Int32.Parse(line));
                }
                else
                    yield return "non numeric values on line";
            }

            public static string GeneratePrimes(int number)
            {
                var primes = new List<int>();

                for (int div = 2; div <= number; div++)
                {
                    while (number % div == 0)
                    {
                        primes.Add(div);
                        number = number / div;
                    }
                }
                string csv = String.Join(",", primes.Select(x => x.ToString()).ToArray());
                return csv;
            }

            public static bool IsInteger(this string s)
            {
                if (String.IsNullOrEmpty(s))
                    return false;

                int i;
                return Int32.TryParse(s, out i);
            }
    }
}
